package com.exp.fragmentui.util;


public interface   I_failure {
    void doFailure();
}
