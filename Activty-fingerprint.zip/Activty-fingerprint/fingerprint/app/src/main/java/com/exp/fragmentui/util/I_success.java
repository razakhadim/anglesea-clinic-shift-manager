package com.exp.fragmentui.util;

import org.json.JSONException;


public interface   I_success {
    void doSuccess(String t) throws JSONException;
}
